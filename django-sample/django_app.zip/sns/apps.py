from django.apps import AppConfig


class SnsConfig(AppConfig):
    name = 'sns'
